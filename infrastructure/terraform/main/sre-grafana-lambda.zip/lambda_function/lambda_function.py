def lambda_handler(event, context):
    # Raise an exception to simulate a server error
    raise Exception("Internal Server Error")